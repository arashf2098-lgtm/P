
'use client';

import { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { 
  Calendar as CalendarIcon, 
  Sparkles, 
  Loader2,
  Zap,
  BookOpen,
  Dumbbell,
  Coffee,
  Library,
  Square,
  CheckSquare,
  ExternalLink,
  Users,
  Wrench,
  Globe
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUser, useDoc, useFirestore } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { AssessmentData } from "@/lib/types";
import { aiScheduleGenerator, AiScheduleOutput } from "@/ai/flows/ai-schedule-generator";
import { generateLocalSchedule } from "@/lib/schedule-algo";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS = {
  study: <BookOpen className="w-4 h-4 text-blue-400" />,
  practice: <Zap className="w-4 h-4 text-yellow-400" />,
  rest: <Coffee className="w-4 h-4 text-green-400" />,
  physical: <Dumbbell className="w-4 h-4 text-red-400" />,
};

const RESOURCE_ICONS: Record<string, any> = {
  course: <BookOpen className="w-4 h-4" />,
  book: <Zap className="w-4 h-4" />,
  community: <Users className="w-4 h-4" />,
  tool: <Wrench className="w-4 h-4" />,
  website: <Globe className="w-4 h-4" />,
};

export default function SchedulePage() {
  const router = useRouter();
  const { user, loading: authLoading } = useUser();
  const firestore = useFirestore();
  
  const userDocRef = useMemo(() => user ? doc(firestore, 'users', user.uid) : null, [user, firestore]);
  const { data: profileDoc, loading: profileLoading } = useDoc(userDocRef);

  const [assessment, setAssessment] = useState<AssessmentData | null>(null);
  const [schedule, setSchedule] = useState<AiScheduleOutput | null>(null);
  const [completedIds, setCompletedIds] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [intensity, setIntensity] = useState<'relaxed' | 'balanced' | 'aggressive'>('balanced');
  const [focusGoal, setFocusGoal] = useState("");

  useEffect(() => {
    if (profileDoc) {
      setAssessment(profileDoc.assessment as AssessmentData);
      setCompletedIds(profileDoc.completedTaskIds || []);
      if (profileDoc.savedSchedule) {
        setSchedule(profileDoc.savedSchedule as AiScheduleOutput);
      }
    } else if (!authLoading && !profileLoading) {
      const stored = localStorage.getItem('pathfinder_last_assessment');
      if (stored) {
        setAssessment(JSON.parse(stored) as AssessmentData);
      } else {
        router.push('/assessment');
      }
    }
  }, [profileDoc, authLoading, profileLoading, router]);

  const saveToCloud = useCallback(async (newSchedule: AiScheduleOutput) => {
    if (!user) return;
    try {
      await setDoc(doc(firestore, 'users', user.uid), {
        savedSchedule: newSchedule
      }, { merge: true });
    } catch (e) {
      console.error("Failed to save schedule:", e);
    }
  }, [user, firestore]);

  const handleGenerateAI = async () => {
    if (!assessment) return;
    setIsGenerating(true);
    try {
      const res = await aiScheduleGenerator({
        freeTimePerWeek: assessment.freeTimePerWeek || 10,
        interests: assessment.interests,
        currentSkills: assessment.skills as any,
        primaryGoal: focusGoal || "General Growth",
        intensity: intensity
      });
      setSchedule(res);
      saveToCloud(res);
      toast({
        title: "AI Schedule Generated",
        description: "Your personalized weekly plan has been saved to your profile."
      });
    } catch (error: any) {
      handleGenerateLocal();
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateLocal = () => {
    if (!assessment) return;
    const res = generateLocalSchedule({
      freeTimePerWeek: assessment.freeTimePerWeek || 10,
      interests: assessment.interests,
      currentSkills: assessment.skills as any,
      primaryGoal: focusGoal || "General Growth",
      intensity: intensity
    });
    setSchedule(res);
    saveToCloud(res);
  };

  const toggleTask = async (day: string, idx: number) => {
    const taskId = `${day}-${idx}`;
    const newCompleted = completedIds.includes(taskId)
      ? completedIds.filter(id => id !== taskId)
      : [...completedIds, taskId];
    
    setCompletedIds(newCompleted);
    
    if (user) {
      await setDoc(doc(firestore, 'users', user.uid), {
        completedTaskIds: newCompleted
      }, { merge: true });
    }
  };

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/20 p-4 md:p-8 pt-24 md:pt-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-4xl font-black tracking-tighter gradient-text">Tactical Scheduler</h1>
            <p className="text-muted-foreground">Persistently track your weekly discovery tasks.</p>
          </div>
          <Button variant="ghost" className="glass" onClick={() => router.push('/dashboard')}>
            Back to Dashboard
          </Button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <Card className="lg:col-span-1 glass border-none shadow-2xl h-fit">
            <CardHeader>
              <CardTitle className="text-lg">Config</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Focus Goal</Label>
                <Input 
                  placeholder="e.g. Design, MMA" 
                  value={focusGoal}
                  onChange={(e) => setFocusGoal(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Intensity</Label>
                <Select value={intensity} onValueChange={(v: any) => setIntensity(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="relaxed">Relaxed</SelectItem>
                    <SelectItem value="balanced">Balanced</SelectItem>
                    <SelectItem value="aggressive">Aggressive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-2">
              <Button className="w-full gradient-bg border-none h-11" onClick={handleGenerateAI} disabled={isGenerating}>
                {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
                AI Sync
              </Button>
              <Button variant="outline" className="w-full glass h-11" onClick={handleGenerateLocal} disabled={isGenerating}>
                Instant Plan
              </Button>
            </CardFooter>
          </Card>

          <Card className="lg:col-span-3 glass border-none shadow-2xl overflow-hidden min-h-[600px] flex flex-col">
            {!schedule ? (
              <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-4">
                <CalendarIcon className="w-12 h-12 text-primary/20" />
                <h3 className="text-xl font-bold">Initialize Tactical Plan</h3>
                <p className="text-sm text-muted-foreground max-w-xs">Use the configuration panel to generate your personalized weekly growth schedule.</p>
              </div>
            ) : (
              <div className="p-0 flex flex-col h-full overflow-hidden">
                <div className="p-6 border-b bg-muted/10">
                  <h2 className="text-xl font-bold">{schedule.title}</h2>
                  <p className="text-xs text-muted-foreground mt-1">{schedule.weeklySummary}</p>
                </div>
                <Tabs defaultValue="Monday" className="w-full flex-1 flex flex-col overflow-hidden">
                  <div className="w-full shrink-0 border-b bg-background/50 overflow-x-auto">
                    <TabsList className="bg-transparent h-12 p-2 gap-1 flex justify-start min-w-max">
                      {schedule.days.map(day => (
                        <TabsTrigger key={day.day} value={day.day} className="data-[state=active]:gradient-bg data-[state=active]:text-white px-4">
                          {day.day}
                        </TabsTrigger>
                      ))}
                      <TabsTrigger value="resources" className="px-4 gap-2">
                        <Library className="w-4 h-4" />
                        Resources
                      </TabsTrigger>
                    </TabsList>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-6">
                      {schedule.days.map(day => (
                        <TabsContent key={day.day} value={day.day} className="mt-0 space-y-4">
                          {day.items.map((item, idx) => (
                            <div 
                              key={idx} 
                              onClick={() => toggleTask(day.day, idx)}
                              className={cn(
                                "group glass border-none p-5 rounded-xl flex items-start gap-6 hover:shadow-lg transition-all cursor-pointer border border-transparent hover:border-primary/20",
                                completedIds.includes(`${day.day}-${idx}`) && "opacity-50 grayscale"
                              )}
                            >
                              <div className="shrink-0 mt-1">
                                {completedIds.includes(`${day.day}-${idx}`) 
                                  ? <CheckSquare className="w-6 h-6 text-primary" /> 
                                  : <Square className="w-6 h-6 text-muted-foreground" />}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  {CATEGORY_ICONS[item.category as keyof typeof CATEGORY_ICONS]}
                                  <h4 className={cn("font-bold text-lg", completedIds.includes(`${day.day}-${idx}`) && "line-through")}>
                                    {item.activity}
                                  </h4>
                                </div>
                                <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                                <div className="mt-3 text-[10px] font-black text-primary uppercase tracking-widest">{item.time}</div>
                              </div>
                            </div>
                          ))}
                        </TabsContent>
                      ))}
                      
                      <TabsContent value="resources" className="mt-0 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {schedule.recommendedResources.map((res, idx) => (
                            <div key={idx} className="p-6 rounded-2xl glass border-none flex items-start gap-4 group hover:shadow-xl transition-all border border-transparent hover:border-primary/20">
                              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                                {RESOURCE_ICONS[res.type] || <BookOpen className="w-6 h-6 text-primary" />}
                              </div>
                              <div className="flex-1">
                                <h6 className="font-black text-base group-hover:text-primary transition-colors flex items-center justify-between">
                                  {res.name}
                                  <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </h6>
                                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{res.description}</p>
                                <Badge variant="secondary" className="mt-3 text-[9px] uppercase tracking-tighter">{res.type}</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="p-6 rounded-xl bg-primary/5 border border-dashed border-primary/20 text-center">
                          <p className="text-sm font-medium text-primary italic">"Quality resources are the fuel for rapid skill acquisition. Use these during your deep work blocks."</p>
                        </div>
                      </TabsContent>
                    </div>
                  </ScrollArea>
                </Tabs>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

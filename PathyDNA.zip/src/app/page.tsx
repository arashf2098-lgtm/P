import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  ArrowRight, 
  BrainCircuit, 
  BarChart3, 
  Compass,
  Sparkles,
  CalendarDays,
  Menu,
  Activity,
  Dna,
  Microscope,
  Database,
  Users,
  Globe,
  Fingerprint
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ThemeToggle } from '@/components/theme-toggle';
import { FloatingBackground } from '@/components/FloatingBackground';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function LandingPage() {
  const NavLinks = () => (
    <>
      <Link href="#features" className="hover:text-primary transition-all">Features</Link>
      <Link href="#purpose" className="hover:text-primary transition-all">Our Purpose</Link>
      <Link href="/schedule" className="hover:text-primary transition-all flex items-center gap-1.5">
        <CalendarDays className="w-4 h-4" />
        Scheduler
      </Link>
      <Link href="#faq" className="hover:text-primary transition-all">FAQ</Link>
    </>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <header className="fixed top-0 w-full z-50 glass border-b">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center shadow-lg shadow-primary/20 glow-primary">
              <Dna className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-black tracking-tighter">PathyDNA <span className="text-[10px] uppercase text-primary ml-1 font-bold tracking-[0.2em] bg-primary/10 px-2 py-0.5 rounded-full">Pro</span></span>
          </div>
          
          <nav className="hidden lg:flex items-center gap-8 text-sm font-semibold text-muted-foreground">
            <NavLinks />
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <ThemeToggle />
            <div className="hidden sm:flex items-center gap-2">
              <Link href="/login">
                <Button variant="ghost" className="font-bold">Log in</Button>
              </Link>
              <Link href="/assessment">
                <Button className="gradient-bg border-none font-bold px-6 shadow-xl shadow-primary/30 hover:scale-105 transition-transform">
                  Join Now
                </Button>
              </Link>
            </div>
            
            <div className="lg:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-xl glass">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="glass border-none w-[300px]">
                  <SheetHeader className="text-left mb-8">
                    <SheetTitle className="flex items-center gap-2">
                      <Dna className="text-primary w-6 h-6" />
                      PathyDNA AI
                    </SheetTitle>
                  </SheetHeader>
                  <div className="flex flex-col gap-6 font-bold text-lg">
                    <NavLinks />
                    <hr className="opacity-20" />
                    <Link href="/login">
                      <Button variant="outline" className="w-full glass">Log in</Button>
                    </Link>
                    <Link href="/assessment">
                      <Button className="w-full gradient-bg border-none">Begin Assessment</Button>
                    </Link>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 pt-20">
        <section className="relative overflow-hidden py-24 lg:py-48">
          <FloatingBackground />
          <div className="container mx-auto px-4 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[10px] sm:text-xs font-bold bg-primary/10 text-primary ring-1 ring-inset ring-primary/20 mb-10 uppercase tracking-widest glow-primary">
              <Sparkles className="h-3.5 w-3.5 animate-pulse" />
              <span>Biometric-Driven Potential Map</span>
            </div>
            <h1 className="text-5xl sm:text-6xl lg:text-8xl font-black tracking-tighter mb-8 leading-[0.9]">
              Find Your <br />
              <span className="gradient-text">True North.</span>
            </h1>
            <p className="max-w-2xl mx-auto text-muted-foreground text-lg sm:text-xl mb-12 font-medium leading-relaxed px-4">
              PathyDNA decodes your unique skills, musculoskeletal predisposition, and psychological drive to reveal your peak professional and athletic trajectory.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 px-4">
              <Link href="/assessment" className="w-full sm:w-auto">
                <Button size="lg" className="w-full h-16 px-12 text-xl font-black gradient-bg shadow-2xl shadow-primary/40 group hover:scale-105 transition-all">
                  Begin Discovery
                  <ArrowRight className="ml-2 h-6 w-6 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link href="/schedule" className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full h-16 px-12 text-xl font-bold glass hover:bg-white/10">
                  Tactical Scheduler
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section id="features" className="py-24 bg-muted/30 relative">
          <div className="absolute top-0 left-0 w-full h-1 gradient-bg opacity-20" />
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-6">The PathyDNA <span className="gradient-text">Ecosystem.</span></h2>
              <p className="text-muted-foreground text-base sm:text-lg font-medium leading-relaxed">
                We've combined behavioral science, biometric analysis, and labor market intelligence into a single platform for your success.
              </p>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
              {[
                { title: 'Skill DNA Profiling', icon: <BrainCircuit className="w-8 h-8" />, color: "bg-indigo-500", desc: 'A multi-dimensional map of your cognitive and practical abilities indexed against 500+ job roles.' },
                { title: 'Tactical Scheduler', icon: <CalendarDays className="w-8 h-8" />, color: "bg-emerald-500", desc: 'AI-optimized weekly plans that turn your long-term roadmap into concrete, achievable daily actions.' },
                { title: 'Biometric Analytics', icon: <Activity className="w-8 h-8" />, color: "bg-amber-500", desc: 'Identifying athletic disciplines where your biology gives you a mathematical advantage.' },
                { title: 'Market Resilience Index', icon: <Compass className="w-8 h-8" />, color: "bg-cyan-500", desc: 'Focusing on careers with high AI-resistance, long-term stability, and high salary ceilings.' },
                { title: 'Goal Velocity', icon: <BarChart3 className="w-8 h-8" />, color: "bg-rose-500", desc: 'Visualizing your execution speed. See exactly how your daily habits contribute to your long-term success.' },
                { title: 'Resource Hub', icon: <Compass className="w-8 h-8" />, color: "bg-violet-500", desc: 'Direct links to the certifications, courses, and communities you need to reach the next level.' },
              ].map((f, i) => (
                <Card key={i} className="glass group hover:shadow-2xl transition-all duration-500 border-none overflow-hidden hover:-translate-y-2">
                  <div className={`h-1.5 w-full ${f.color} opacity-20 group-hover:opacity-100 transition-opacity`} />
                  <CardContent className="p-8 sm:p-10">
                    <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl ${f.color} flex items-center justify-center text-white mb-6 sm:mb-8 group-hover:rotate-6 transition-transform shadow-xl shadow-black/10`}>
                      {f.icon}
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black mb-4 group-hover:text-primary transition-colors">{f.title}</h3>
                    <p className="text-muted-foreground font-medium leading-relaxed text-sm sm:text-base">{f.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section id="purpose" className="py-24 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-8">
                <Badge variant="outline" className="px-4 py-1 text-primary border-primary/20 font-bold uppercase tracking-widest">Scientific Basis</Badge>
                <h2 className="text-4xl lg:text-6xl font-black tracking-tighter leading-tight">
                  Decoding <br />
                  <span className="gradient-text">Human Output.</span>
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed font-medium">
                  We believe that the current model of career and athletic selection is outdated. PathyDNA uses data-driven discovery to map individuals to the paths where they are biologically destined to thrive.
                </p>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="flex items-start gap-4 p-4 rounded-2xl glass border-none">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Microscope className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Biometric Precision</h4>
                      <p className="text-xs text-muted-foreground">Mapping skeletal and muscular structure to performance.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 rounded-2xl glass border-none">
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                      <Database className="w-5 h-5 text-accent-foreground" />
                    </div>
                    <div>
                      <h4 className="font-bold text-lg">Predictive Modeling</h4>
                      <p className="text-xs text-muted-foreground">Using labor market data to predict future role stability.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl rotate-3 scale-95 hover:rotate-0 hover:scale-100 transition-all duration-700">
                  <Image 
                    src="https://picsum.photos/seed/pathydna-dna/800/800" 
                    alt="Precision Discovery" 
                    width={800}
                    height={800}
                    priority
                    data-ai-hint="DNA structure"
                    className="w-full h-full object-cover" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
                  <div className="absolute bottom-10 left-10 text-white space-y-2">
                    <p className="text-4xl font-black">22k+</p>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-80">Skill Nodes Mapped</p>
                  </div>
                </div>
                <div className="absolute -top-10 -right-10 w-40 h-40 gradient-bg rounded-full blur-3xl opacity-20 animate-pulse" />
              </div>
            </div>
          </div>
        </section>

        <section id="faq" className="py-24 bg-muted/20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto space-y-12">
              <div className="text-center space-y-4">
                <h2 className="text-4xl font-black tracking-tight">Technical <span className="gradient-text">FAQ.</span></h2>
                <p className="text-muted-foreground font-medium">Deep dive into the PathyDNA discovery process.</p>
              </div>
              
              <Accordion type="single" collapsible className="w-full space-y-4">
                <AccordionItem value="item-1" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">How accurate is the Skill DNA profiling?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    Our profiling engine uses a proprietary algorithm that cross-references 12 unique skill dimensions with real-time labor market data. While no prediction is 100%, our model consistently identifies paths with the highest mathematical probability of success based on your current aptitude.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">What is "Biometric Analytics"?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    This is an advanced biometric assessment where we analyze your skeletal structure, muscle distribution, and physiological traits to suggest sports or physical disciplines where you have a natural mechanical advantage. This minimizes injury risk and maximizes performance ceilings.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">How does the AI generate my recommendations?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    We utilize Genkit and Google's Gemini models to synthesize your assessment data—including skills, budget, and time availability—against a massive database of career and athletic requirements. The result is a highly personalized "path" that aligns with your specific constraints.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">Is my biometric and profile data secure?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    Yes. All user data is stored securely in Firebase with strict security rules. We use end-to-end encryption for sensitive data and never share your individual biometric profile with third parties without your explicit consent.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">Can I use PathyDNA for career transitions?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    Absolutely. PathyDNA is especially powerful for career switchers. It identifies "transferable DNA"—skills you already possess that are highly valued in different industries—helping you pivot into a new career with confidence and a clear learning roadmap.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-6" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">How often should I update my profile?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    We recommend updating your assessment every 3-6 months or after completing a major milestone in your learning roadmap. As you acquire new skills, your "Skill DNA" evolves, potentially opening up even higher-tier recommendations.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-7" className="glass border-none px-6 rounded-2xl">
                  <AccordionTrigger className="text-lg font-bold hover:no-underline">What makes the Tactical Scheduler unique?</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    Unlike generic calendars, the Tactical Scheduler is "persistence-aware." It doesn't just block time; it assigns specific, AI-recommended tasks that are foundational to your chosen path. It tracks your "Goal Velocity" to show you exactly how your daily habits are moving the needle.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-24 bg-muted/20 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-center md:text-left mb-16">
            <div className="md:col-span-2 space-y-6">
              <div className="flex items-center justify-center md:justify-start gap-3">
                <Dna className="text-primary w-8 h-8" />
                <span className="text-3xl font-black tracking-tighter">PathyDNA Discovery</span>
              </div>
              <p className="text-muted-foreground max-w-md font-medium text-sm sm:text-base leading-relaxed">
                Empowering global talent through AI-driven self-actualization. Decoding human potential through biometric precision and labor market intelligence.
              </p>
              <div className="flex justify-center md:justify-start gap-4">
                <Link href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Users className="w-4 h-4" /></Link>
                <Link href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Globe className="w-4 h-4" /></Link>
                <Link href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center hover:bg-primary hover:text-white transition-all"><Fingerprint className="w-4 h-4" /></Link>
              </div>
            </div>
            <div className="space-y-6">
              <h4 className="font-black text-sm uppercase tracking-widest">Platform</h4>
              <ul className="space-y-4 text-sm font-bold text-muted-foreground">
                <li><Link href="#features" className="hover:text-primary transition-colors">Features</Link></li>
                <li><Link href="/schedule" className="hover:text-primary transition-colors">Tactical Scheduler</Link></li>
                <li><Link href="/assessment" className="hover:text-primary transition-colors">Skill Assessment</Link></li>
                <li><Link href="/dashboard" className="hover:text-primary transition-colors">Dashboard</Link></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h4 className="font-black text-sm uppercase tracking-widest">Legal</h4>
              <ul className="space-y-4 text-sm font-bold text-muted-foreground">
                <li><Link href="#" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Terms of Service</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Data Security</Link></li>
                <li><Link href="#" className="hover:text-primary transition-colors">Cookie Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t text-xs sm:text-sm text-muted-foreground font-bold flex flex-col md:flex-row justify-between items-center gap-4">
            <div>© 2024 PathyDNA AI Discovery. All rights reserved.</div>
            <div className="flex gap-8">
              <Link href="#" className="hover:text-primary transition-colors">Twitter</Link>
              <Link href="#" className="hover:text-primary transition-colors">LinkedIn</Link>
              <Link href="#" className="hover:text-primary transition-colors">Instagram</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}


"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  Shield,
  Target,
  Sparkles,
  Loader2
} from "lucide-react";
import { AssessmentData, EducationLevel } from "@/lib/types";
import { useUser, useFirestore } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const STEPS = [
  "Personal Information",
  "Budget & Resources",
  "Skills Assessment",
  "Interests & Preferences",
  "Physical Profile"
];

const INTEREST_OPTIONS = [
  "Technology", "Science", "Business", "Arts", "Sports", 
  "Education", "Healthcare", "Engineering", "Finance", "Entrepreneurship"
];

const SKILL_DESCRIPTIONS: Record<string, string> = {
  mathematics: "Logical reasoning and numerical proficiency.",
  problemSolving: "Ability to decompose and solve complex issues.",
  communication: "Effectiveness in verbal and written exchange.",
  leadership: "Leading teams and making strategic decisions.",
  creativity: "Thinking outside conventional frameworks.",
  programming: "Computational logic and software construction.",
  physicalFitness: "General athletic endurance and strength.",
  coordination: "Hand-eye and full-body motor control.",
  teamwork: "Collaborative efficiency in group settings.",
  discipline: "Consistency and adherence to long-term goals."
};

export default function AssessmentWizard() {
  const router = useRouter();
  const { user } = useUser();
  const firestore = useFirestore();
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [data, setData] = useState<AssessmentData>({
    skills: {
      mathematics: 5, problemSolving: 5, communication: 5, leadership: 5,
      creativity: 5, programming: 5, physicalFitness: 5, coordination: 5,
      teamwork: 5, discipline: 5
    },
    interests: [],
    preferences: {
      indoorVsOutdoor: 'Both',
      teamVsIndividual: 'Both',
      analyticalVsCreative: 'Both',
      physicalVsMental: 'Both'
    },
    physical: {}
  });

  const progress = ((currentStep + 1) / STEPS.length) * 100;

  const handleNext = async () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    } else {
      setIsSubmitting(true);
      try {
        localStorage.setItem('pathfinder_last_assessment', JSON.stringify(data));
        
        if (user) {
          await setDoc(doc(firestore, 'users', user.uid), {
            userId: user.uid,
            assessment: data,
            createdAt: new Date().toISOString()
          }, { merge: true });
        }
        
        router.push('/dashboard');
      } catch (error: any) {
        toast({
          variant: "destructive",
          title: "Error saving assessment",
          description: error.message
        });
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const updateSkill = (skill: string, value: number[]) => {
    setData(prev => ({
      ...prev,
      skills: { ...prev.skills, [skill]: value[0] }
    }));
  };

  const toggleInterest = (interest: string) => {
    setData(prev => {
      const interests = prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest];
      return { ...prev, interests };
    });
  };

  return (
    <div className="min-h-screen bg-muted/30 py-12 px-4 flex items-center justify-center">
      <div className="w-full max-w-4xl space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-black tracking-tighter uppercase">Discovery Assessment</h1>
          <p className="text-muted-foreground font-medium">Step {currentStep + 1}: {STEPS[currentStep]}</p>
          <div className="max-w-md mx-auto pt-4 space-y-2">
            <Progress value={progress} className="h-3 shadow-inner" />
            <div className="flex justify-between text-[10px] text-muted-foreground font-black uppercase tracking-widest px-1">
              <span>Initialization</span>
              <span>Finalization</span>
            </div>
          </div>
        </div>

        <Card className="glass border-none shadow-3xl overflow-hidden rounded-3xl">
          <div className="h-2 gradient-bg" />
          <CardContent className="p-10">
            {currentStep === 0 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label className="font-black text-sm uppercase tracking-widest">Chronological Age</Label>
                    <Input 
                      type="number" 
                      placeholder="e.g. 25" 
                      className="h-12 glass"
                      value={data.age || ''}
                      onChange={e => setData({...data, age: parseInt(e.target.value) || 0})}
                    />
                  </div>
                  <div className="space-y-3">
                    <Label className="font-black text-sm uppercase tracking-widest">Gender Identity</Label>
                    <Select onValueChange={v => setData({...data, gender: v})}>
                      <SelectTrigger className="h-12 glass">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="non-binary">Non-binary</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-3">
                  <Label className="font-black text-sm uppercase tracking-widest">Country of Residence</Label>
                  <Input 
                    placeholder="e.g. USA" 
                    className="h-12 glass"
                    value={data.country || ''}
                    onChange={e => setData({...data, country: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <Label className="font-black text-sm uppercase tracking-widest">Highest Educational Credential</Label>
                  <Select onValueChange={(v: EducationLevel) => setData({...data, educationLevel: v})}>
                    <SelectTrigger className="h-12 glass">
                      <SelectValue placeholder="Select your current level" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Middle School', 'High School', 'College', 'Bachelor', 'Master', 'PhD'].map(lvl => (
                        <SelectItem key={lvl} value={lvl as EducationLevel}>{lvl}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="space-y-6 p-6 rounded-2xl bg-primary/5 border border-primary/10">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-sm uppercase tracking-widest">Monthly Hobby Budget</Label>
                    <Badge className="font-mono text-lg gradient-bg border-none">${data.monthlyHobbyBudget || 0}</Badge>
                  </div>
                  <Slider 
                    max={2000} 
                    step={50} 
                    value={[data.monthlyHobbyBudget || 0]} 
                    onValueChange={v => setData({...data, monthlyHobbyBudget: v[0]})} 
                  />
                  <p className="text-xs text-muted-foreground font-medium italic">Funds allocated for equipment, memberships, and casual learning.</p>
                </div>

                <div className="space-y-6 p-6 rounded-2xl bg-accent/5 border border-accent/10">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-sm uppercase tracking-widest">Total Education Budget</Label>
                    <Badge className="font-mono text-lg bg-accent text-accent-foreground border-none">${data.educationBudget || 0}</Badge>
                  </div>
                  <Slider 
                    max={100000} 
                    step={1000} 
                    value={[data.educationBudget || 0]} 
                    onValueChange={v => setData({...data, educationBudget: v[0]})} 
                  />
                  <p className="text-xs text-muted-foreground font-medium italic">Available capital for long-term training, degrees, or certifications.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="flex items-center justify-between p-6 border rounded-2xl glass hover:border-primary/50 transition-colors">
                    <div className="space-y-1">
                      <Label className="font-black uppercase tracking-tighter">Digital Access</Label>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Stable internet</p>
                    </div>
                    <Switch checked={data.internetAccess} onCheckedChange={v => setData({...data, internetAccess: v})} />
                  </div>
                  <div className="flex items-center justify-between p-6 border rounded-2xl glass hover:border-primary/50 transition-colors">
                    <div className="space-y-1">
                      <Label className="font-black uppercase tracking-tighter">Mobility Access</Label>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Reliable transport</p>
                    </div>
                    <Switch checked={data.transportationAccess} onCheckedChange={v => setData({...data, transportationAccess: v})} />
                  </div>
                </div>

                <div className="space-y-6 p-6 rounded-2xl bg-muted/50 border">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-sm uppercase tracking-widest">Weekly Free Capacity</Label>
                    <Badge variant="outline" className="font-mono text-lg">{data.freeTimePerWeek || 0} HOURS</Badge>
                  </div>
                  <Slider 
                    max={168} 
                    step={1} 
                    value={[data.freeTimePerWeek || 0]} 
                    onValueChange={v => setData({...data, freeTimePerWeek: v[0]})} 
                  />
                  <p className="text-xs text-muted-foreground font-medium italic">Total hours per week you can realistically dedicate to your new path.</p>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="text-center mb-8">
                  <p className="text-muted-foreground font-medium italic">Be honest. This skill DNA is the core of our matching algorithm.</p>
                </div>
                <div className="grid gap-8">
                  {Object.keys(data.skills).map((skill) => (
                    <div key={skill} className="space-y-4 group">
                      <div className="flex justify-between items-center">
                        <div className="space-y-1">
                          <Label className="capitalize font-black text-lg group-hover:text-primary transition-colors">{skill.replace(/([A-Z])/g, ' $1')}</Label>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">{SKILL_DESCRIPTIONS[skill]}</p>
                        </div>
                        <Badge variant="outline" className="font-mono text-lg h-10 w-12 flex items-center justify-center border-primary/20">
                          {data.skills[skill as keyof typeof data.skills]}
                        </Badge>
                      </div>
                      <Slider 
                        max={10} 
                        min={1} 
                        step={1} 
                        value={[data.skills[skill as keyof typeof data.skills]]} 
                        onValueChange={v => updateSkill(skill, v)} 
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="space-y-6">
                  <Label className="font-black text-sm uppercase tracking-widest flex items-center gap-2">
                    <Target className="w-4 h-4 text-primary" />
                    Target Domains
                  </Label>
                  <div className="flex flex-wrap gap-3">
                    {INTEREST_OPTIONS.map(interest => (
                      <Badge 
                        key={interest}
                        variant={data.interests.includes(interest) ? "default" : "outline"}
                        className={cn(
                          "cursor-pointer py-3 px-6 text-sm transition-all rounded-xl",
                          data.interests.includes(interest) ? "shadow-lg shadow-primary/20" : "hover:border-primary/50"
                        )}
                        onClick={() => toggleInterest(interest)}
                      >
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="grid gap-8">
                  <Label className="font-black text-sm uppercase tracking-widest flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    Operational Preferences
                  </Label>
                  {[
                    { label: "Environment Bias", key: "indoorVsOutdoor", options: ["Indoor", "Outdoor", "Both"] },
                    { label: "Collaboration Bias", key: "teamVsIndividual", options: ["Team", "Individual", "Both"] },
                    { label: "Cognitive Bias", key: "analyticalVsCreative", options: ["Analytical", "Creative", "Both"] },
                    { label: "Physiological Bias", key: "physicalVsMental", options: ["Physical", "Mental", "Both"] },
                  ].map((pref) => (
                    <div key={pref.key} className="space-y-3">
                      <Label className="text-xs font-bold uppercase text-muted-foreground">{pref.label}</Label>
                      <div className="flex gap-2">
                        {pref.options.map(opt => (
                          <Button
                            key={opt}
                            variant={data.preferences[pref.key as keyof typeof data.preferences] === opt ? "default" : "outline"}
                            size="lg"
                            className={cn(
                              "flex-1 font-bold h-12 rounded-xl",
                              data.preferences[pref.key as keyof typeof data.preferences] === opt && "shadow-lg"
                            )}
                            onClick={() => setData({
                              ...data, 
                              preferences: { ...data.preferences, [pref.key as keyof typeof data.preferences]: opt as any }
                            })}
                          >
                            {opt}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-12 text-center py-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="w-24 h-24 rounded-3xl gradient-bg flex items-center justify-center mx-auto mb-8 shadow-2xl rotate-3">
                  <Shield className="w-12 h-12 text-white" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black tracking-tight">Final Calibration.</h3>
                  <p className="text-muted-foreground max-w-sm mx-auto font-medium">
                    Musculoskeletal metrics are optional but critical for elite athletic matching.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-8 text-left max-w-lg mx-auto">
                  <div className="space-y-3">
                    <Label className="font-black text-sm uppercase tracking-widest">Height (cm)</Label>
                    <Input type="number" className="h-14 glass text-lg font-bold" onChange={e => setData({...data, physical: {...data.physical, height: parseInt(e.target.value) || 0}})} />
                  </div>
                  <div className="space-y-3">
                    <Label className="font-black text-sm uppercase tracking-widest">Weight (kg)</Label>
                    <Input type="number" className="h-14 glass text-lg font-bold" onChange={e => setData({...data, physical: {...data.physical, weight: parseInt(e.target.value) || 0}})} />
                  </div>
                </div>
                
                <div className="space-y-3 text-left max-w-lg mx-auto">
                  <Label className="font-black text-sm uppercase tracking-widest">Injury History / Physiological Notes</Label>
                  <Input 
                    placeholder="e.g. Previous ACL surgery, chronic back sensitivity" 
                    className="h-14 glass"
                    onChange={e => setData({...data, physical: {...data.physical, existingInjuries: [e.target.value]}})} 
                  />
                </div>

                <div className="pt-8 flex flex-col items-center gap-4">
                  <CheckCircle2 className="w-10 h-10 text-primary animate-bounce" />
                  <p className="text-sm font-black uppercase tracking-[0.2em] text-primary">Ready for synthesis</p>
                </div>
              </div>
            )}
          </CardContent>
          <div className="flex justify-between p-10 border-t bg-muted/10">
            <Button variant="ghost" size="lg" className="px-8 font-bold" onClick={handleBack} disabled={currentStep === 0 || isSubmitting}>
              <ChevronLeft className="mr-2 w-5 h-5" />
              Back
            </Button>
            <Button className="gradient-bg px-12 h-14 text-lg font-black shadow-2xl shadow-primary/30" onClick={handleNext} disabled={isSubmitting}>
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Synthesizing...
                </div>
              ) : (
                <>
                  {currentStep === STEPS.length - 1 ? "Complete Analysis" : "Continue"}
                  <ChevronRight className="ml-2 w-5 h-5" />
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

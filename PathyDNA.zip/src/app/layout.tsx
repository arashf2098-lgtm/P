import type {Metadata} from 'next';
import './globals.css';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import { ChatBot } from '@/components/ChatBot';
import { Inter } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'PathyDNA | AI Skill Profiling & Growth',
  description: 'Unlock your potential with PathyDNA. Discover your ideal professional and athletic paths using advanced AI skill DNA profiling.',
  keywords: ['PathyDNA', 'AI Skill DNA', 'Career Growth', 'Athletic Discovery', 'Personal Optimization'],
  authors: [{ name: 'PathyDNA Team' }],
  metadataBase: new URL('https://pathydna.app'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'PathyDNA | AI Skill DNA & Career Growth',
    description: 'Find your true north. Discover your ideal career and sports paths based on PathyDNA skill profiling.',
    url: 'https://pathydna.app',
    siteName: 'PathyDNA',
    locale: 'en_US',
    type: 'website',
    images: [
      {
        url: 'https://picsum.photos/seed/pathydna-og/1200/630',
        width: 1200,
        height: 630,
        alt: 'PathyDNA Dashboard',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PathyDNA | AI Skill DNA & Career Growth',
    description: 'Unlock your potential with PathyDNA AI and strategic growth planning.',
    images: ['https://picsum.photos/seed/pathydna-og/1200/630'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={inter.variable}>
      <body className="font-body antialiased selection:bg-primary selection:text-white transition-colors duration-300">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <FirebaseClientProvider>
            {children}
            <ChatBot />
            <Toaster />
          </FirebaseClientProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}

'use client';

import { 
  Briefcase, 
  Dumbbell, 
  Code, 
  Trophy, 
  Stethoscope, 
  Gamepad2, 
  Cpu, 
  Heart,
  Bike,
  Rocket,
  Zap,
  Star,
  Globe,
  Music
} from 'lucide-react';
import React, { useEffect, useState } from 'react';

const ICONS = [
  Briefcase, Dumbbell, Code, Trophy, Stethoscope, 
  Gamepad2, Cpu, Heart, Bike, Rocket, Zap, Star, Globe, Music
];

const COLORS = [
  'text-primary',
  'text-secondary',
  'text-accent',
  'text-emerald-400',
  'text-violet-400',
  'text-amber-400'
];

export const FloatingBackground = React.memo(function FloatingBackground() {
  const [elements, setElements] = useState<{ id: number, Icon: any, top: string, left: string, delay: string, size: number, opacity: number, color: string }[]>([]);

  useEffect(() => {
    // Reduced count for better performance on mobile/low-end devices
    const count = 15; 
    const newElements = Array.from({ length: count }).map((_, i) => ({
      id: i,
      Icon: ICONS[i % ICONS.length],
      top: `${Math.random() * 100}%`,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * -20}s`,
      size: 20 + Math.random() * 40,
      opacity: 0.04 + Math.random() * 0.08,
      color: COLORS[i % COLORS.length]
    }));
    setElements(newElements);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none -z-10">
      {elements.map((el) => (
        <div
          key={el.id}
          className={`absolute animate-float ${el.color} will-change-transform`}
          style={{
            top: el.top,
            left: el.left,
            animationDelay: el.delay,
            opacity: el.opacity,
            width: el.size,
            height: el.size,
          }}
        >
          <el.Icon size={el.size} strokeWidth={1} />
        </div>
      ))}
    </div>
  );
});

'use client';

import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer 
} from 'recharts';

interface RadarDNAChartProps {
  data: {
    subject: string;
    A: number;
    fullMark: number;
  }[];
}

export default function RadarDNAChart({ data }: RadarDNAChartProps) {
  return (
    <div className="h-[250px] sm:h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="75%" data={data}>
          <PolarGrid stroke="hsl(var(--muted-foreground))" strokeOpacity={0.1} />
          <PolarAngleAxis 
            dataKey="subject" 
            tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))', fontWeight: 900 }} 
          />
          <Radar
            name="User"
            dataKey="A"
            stroke="hsl(var(--primary))"
            fill="hsl(var(--primary))"
            fillOpacity={0.4}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

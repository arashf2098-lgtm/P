export type EducationLevel = 'Middle School' | 'High School' | 'College' | 'Bachelor' | 'Master' | 'PhD';

export interface UserSkills {
  mathematics: number;
  problemSolving: number;
  communication: number;
  leadership: number;
  creativity: number;
  programming: number;
  physicalFitness: number;
  coordination: number;
  teamwork: number;
  discipline: number;
}

export interface UserPreferences {
  indoorVsOutdoor: 'Indoor' | 'Outdoor' | 'Both';
  teamVsIndividual: 'Team' | 'Individual' | 'Both';
  analyticalVsCreative: 'Analytical' | 'Creative' | 'Both';
  physicalVsMental: 'Physical' | 'Mental' | 'Both';
}

export interface PhysicalInfo {
  height?: number;
  weight?: number;
  fitnessLevel?: string;
  existingInjuries?: string[];
  sportsExperience?: string;
}

export interface AssessmentData {
  age?: number;
  gender?: string;
  country?: string;
  educationLevel?: EducationLevel;
  monthlyHobbyBudget?: number;
  educationBudget?: number;
  internetAccess?: boolean;
  transportationAccess?: boolean;
  freeTimePerWeek?: number;
  skills: UserSkills;
  interests: string[];
  preferences: UserPreferences;
  physical: PhysicalInfo;
}

export interface Career {
  id: string;
  name: string;
  category: string;
  requiredSkills: string[];
  averageSalary: number;
  growthRate: number;
  difficulty: string;
  trainingCost: number;
  description: string;
  learningTime: string;
  skillWeights?: Partial<Record<keyof UserSkills, number>>;
}

export interface Sport {
  id: string;
  name: string;
  category: string;
  equipmentCost: number;
  fitnessRequirement: number;
  teamworkLevel: number;
  description: string;
  trainingFrequency: string;
  difficulty: string;
}

export interface RecommendationMatch {
  item: Career | Sport;
  matchScore: number;
  type: 'career' | 'sport';
}
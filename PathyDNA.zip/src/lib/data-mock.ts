
import { Career, Sport } from './types';

export const MOCK_CAREERS: Career[] = [
  {
    id: 'c1',
    name: 'Software Engineer',
    category: 'Technology',
    requiredSkills: ['Programming', 'Problem Solving', 'Mathematics'],
    averageSalary: 125000,
    growthRate: 25,
    difficulty: 'High',
    trainingCost: 15000,
    description: 'Architecting digital systems and building high-scale applications. You will be responsible for translating complex requirements into elegant, efficient, and maintainable code bases.',
    learningTime: '2-4 years',
    skillWeights: { programming: 10, problemSolving: 8, mathematics: 6, discipline: 7 }
  },
  {
    id: 'c2',
    name: 'Data Scientist',
    category: 'Science',
    requiredSkills: ['Mathematics', 'Programming', 'Problem Solving'],
    averageSalary: 140000,
    growthRate: 35,
    difficulty: 'High',
    trainingCost: 20000,
    description: 'Extracting actionable insights from massive, complex datasets using statistical modeling and machine learning algorithms to drive organizational strategy.',
    learningTime: '3-5 years',
    skillWeights: { mathematics: 10, problemSolving: 9, programming: 7, discipline: 8 }
  },
  {
    id: 'c3',
    name: 'Creative Director',
    category: 'Arts',
    requiredSkills: ['Creativity', 'Communication', 'Leadership'],
    averageSalary: 110000,
    growthRate: 10,
    difficulty: 'Medium',
    trainingCost: 12000,
    description: 'Leading the visual and conceptual identity of brands and high-end creative projects. You orchestrate teams of designers, writers, and artists to deliver cohesive brand narratives.',
    learningTime: '5-8 years',
    skillWeights: { creativity: 10, communication: 9, leadership: 8, teamwork: 7 }
  },
  {
    id: 'c4',
    name: 'Mechanical Engineer',
    category: 'Engineering',
    requiredSkills: ['Mathematics', 'Problem Solving', 'Design'],
    averageSalary: 95000,
    growthRate: 12,
    difficulty: 'High',
    trainingCost: 45000,
    description: 'Designing and testing mechanical sensors and robotic devices. This role requires a deep understanding of physics and material sciences to create physical solutions to real-world problems.',
    learningTime: '4 years',
    skillWeights: { mathematics: 9, problemSolving: 9, coordination: 6, discipline: 7 }
  },
  {
    id: 'c5',
    name: 'Registered Nurse',
    category: 'Healthcare',
    requiredSkills: ['Communication', 'Teamwork', 'Discipline'],
    averageSalary: 82000,
    growthRate: 18,
    difficulty: 'Medium',
    trainingCost: 35000,
    description: 'Providing critical patient care and managing medical administrative tasks in high-pressure clinical environments.',
    learningTime: '2-4 years',
    skillWeights: { communication: 10, discipline: 9, teamwork: 9, coordination: 7 }
  },
  {
    id: 'c6',
    name: 'Digital Marketing Manager',
    category: 'Business',
    requiredSkills: ['Communication', 'Creativity', 'Problem Solving'],
    averageSalary: 88000,
    growthRate: 22,
    difficulty: 'Medium',
    trainingCost: 5000,
    description: 'Orchestrating multi-channel digital campaigns to drive brand growth. You will use data analytics to optimize spending and maximize customer acquisition.',
    learningTime: '1-3 years',
    skillWeights: { communication: 9, creativity: 8, problemSolving: 7, leadership: 6 }
  },
  {
    id: 'c7',
    name: 'Financial Analyst',
    category: 'Finance',
    requiredSkills: ['Mathematics', 'Problem Solving', 'Communication'],
    averageSalary: 92000,
    growthRate: 15,
    difficulty: 'High',
    trainingCost: 15000,
    description: 'Guiding investment decisions through rigorous quantitative analysis and financial forecasting.',
    learningTime: '3-5 years',
    skillWeights: { mathematics: 9, problemSolving: 8, communication: 7, discipline: 8 }
  },
  {
    id: 'c8',
    name: 'Cybersecurity Analyst',
    category: 'Technology',
    requiredSkills: ['Programming', 'Problem Solving', 'Discipline'],
    averageSalary: 115000,
    growthRate: 40,
    difficulty: 'High',
    trainingCost: 10000,
    description: 'Protecting organizational networks from sophisticated cyber threats and ensuring data integrity through advanced security protocols.',
    learningTime: '2-4 years',
    skillWeights: { programming: 8, problemSolving: 10, discipline: 10, mathematics: 5 }
  },
  {
    id: 'c9',
    name: 'Environmental Consultant',
    category: 'Science',
    requiredSkills: ['Problem Solving', 'Communication', 'Science'],
    averageSalary: 78000,
    growthRate: 20,
    difficulty: 'Medium',
    trainingCost: 25000,
    description: 'Advising on environmental impacts and sustainable operational practices to ensure compliance with global ecological standards.',
    learningTime: '4 years',
    skillWeights: { problemSolving: 8, communication: 8, creativity: 5, discipline: 6 }
  },
  {
    id: 'c10',
    name: 'UX/UI Designer',
    category: 'Technology',
    requiredSkills: ['Creativity', 'Problem Solving', 'Communication'],
    averageSalary: 98000,
    growthRate: 28,
    difficulty: 'Medium',
    trainingCost: 8000,
    description: 'Designing intuitive and aesthetically pleasing digital interfaces. You balance user needs with technical feasibility and business goals.',
    learningTime: '1-2 years',
    skillWeights: { creativity: 10, problemSolving: 8, communication: 7, teamwork: 6 }
  }
];

export const MOCK_SPORTS: Sport[] = [
  {
    id: 's1',
    name: 'Basketball',
    category: 'Team Sports',
    equipmentCost: 50,
    fitnessRequirement: 8,
    teamworkLevel: 10,
    description: 'High-intensity team sport emphasizing coordination, explosive power, and tactical positioning.',
    trainingFrequency: '3-5 times a week',
    difficulty: 'Medium',
    fitnessBenefits: 'Elite cardiovascular health, vertical explosive power, and full-body coordination.'
  },
  {
    id: 's2',
    name: 'Rock Climbing',
    category: 'Extreme Sports',
    equipmentCost: 500,
    fitnessRequirement: 9,
    teamworkLevel: 3,
    description: 'A vertical challenge requiring massive relative strength, extreme mental fortitude, and precise spatial awareness.',
    trainingFrequency: '2-4 times a week',
    difficulty: 'High',
    fitnessBenefits: 'Superior upper body strength, core stability, and mental resilience.'
  },
  {
    id: 's3',
    name: 'Swimming',
    category: 'Individual Sports',
    equipmentCost: 100,
    fitnessRequirement: 10,
    teamworkLevel: 1,
    description: 'Full-body cardiovascular conditioning with zero impact on joints. Ideal for building extreme aerobic capacity.',
    trainingFrequency: '4-6 times a week',
    difficulty: 'Low',
    fitnessBenefits: 'Maximum lung capacity, lean muscle development, and joint longevity.'
  },
  {
    id: 's4',
    name: 'Chess',
    category: 'Mental Sports',
    equipmentCost: 20,
    fitnessRequirement: 1,
    teamworkLevel: 1,
    description: 'The ultimate strategic mental duel, requiring extreme foresight, pattern recognition, and psychological patience.',
    trainingFrequency: 'Daily',
    difficulty: 'High',
    fitnessBenefits: 'Cognitive endurance, long-term focus, and emotional regulation.'
  },
  {
    id: 's5',
    name: 'Mixed Martial Arts (MMA)',
    category: 'Combat Sports',
    equipmentCost: 400,
    fitnessRequirement: 10,
    teamworkLevel: 2,
    description: 'Comprehensive combat system requiring elite fitness, extreme discipline, and mastery across multiple fighting disciplines.',
    trainingFrequency: '5-6 times a week',
    difficulty: 'High',
    fitnessBenefits: 'Peak physical conditioning, defensive reflexes, and unmatched self-discipline.'
  }
];

import { AssessmentData, Career, Sport, RecommendationMatch } from './types';

export function calculateCareerMatch(user: AssessmentData, career: Career): number {
  // 40% Skills
  const skillMatch = career.skillWeights 
    ? Object.entries(career.skillWeights).reduce((acc, [skill, weight]) => {
        const userLevel = user.skills[skill as keyof typeof user.skills] || 1;
        return acc + (userLevel / 10) * weight;
      }, 0) / Object.values(career.skillWeights).reduce((a, b) => a + b, 0)
    : 0.5;

  // 30% Interests
  const interestMatch = user.interests.includes(career.category) ? 1 : 0.4;

  // 20% Budget
  const budgetRatio = user.educationBudget && user.educationBudget > 0 
    ? Math.min(1, user.educationBudget / career.trainingCost) 
    : 0.5;

  // 10% Education
  const educationScores: Record<string, number> = {
    'Middle School': 0.1,
    'High School': 0.3,
    'College': 0.5,
    'Bachelor': 0.8,
    'Master': 0.9,
    'PhD': 1.0
  };
  const eduMatch = educationScores[user.educationLevel || 'High School'] || 0.5;

  const score = (skillMatch * 0.4) + (interestMatch * 0.3) + (budgetRatio * 0.2) + (eduMatch * 0.1);
  return Math.round(score * 100);
}

export function calculateSportMatch(user: AssessmentData, sport: Sport): number {
  // 35% Physical Profile
  const fitnessMatch = (user.skills.physicalFitness / 10) * (sport.fitnessRequirement / 10);
  const physicalMatch = Math.min(1, fitnessMatch + 0.5);

  // 35% Interests
  const interestMatch = user.interests.includes('Sports') ? 1 : 0.6;

  // 20% Budget
  const budgetMatch = user.monthlyHobbyBudget && user.monthlyHobbyBudget > 0
    ? Math.min(1, user.monthlyHobbyBudget / (sport.equipmentCost / 12)) // monthly equip cost
    : 0.7;

  // 10% Free Time
  const timeMatch = Math.min(1, (user.freeTimePerWeek || 5) / 10);

  const score = (physicalMatch * 0.35) + (interestMatch * 0.35) + (budgetMatch * 0.2) + (timeMatch * 0.1);
  return Math.round(score * 100);
}
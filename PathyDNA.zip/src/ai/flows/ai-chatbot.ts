'use server';
/**
 * @fileOverview An AI chatbot flow that provides personalized guidance and can suggest 
 * updates to the user's career/sport assessment based on the conversation.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'model', 'system']),
  text: z.string(),
});

const AiChatBotInputSchema = z.object({
  history: z.array(ChatMessageSchema).describe('The conversation history.'),
  userInput: z.string().describe('The latest message from the user.'),
  currentAssessment: z.any().describe('The user\'s current assessment data for context.'),
});
export type AiChatBotInput = z.infer<typeof AiChatBotInputSchema>;

const AiChatBotOutputSchema = z.object({
  response: z.string().describe('The AI\'s conversational response.'),
  suggestedAssessmentUpdate: z.object({
    skills: z.record(z.number()).optional(),
    interests: z.array(z.string()).optional(),
    reasoning: z.string().optional().describe('Why this update is being suggested.'),
  }).optional().describe('A suggested update to the user\'s profile based on the chat.'),
});
export type AiChatBotOutput = z.infer<typeof AiChatBotOutputSchema>;

export async function aiChatBot(input: AiChatBotInput): Promise<AiChatBotOutput> {
  return aiChatBotFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiChatBotPrompt',
  input: { schema: AiChatBotInputSchema },
  output: { schema: AiChatBotOutputSchema },
  prompt: `You are "Pathy", the friendly and expert AI guide for PathFinder. 
Your goal is to help users understand their career and sport recommendations, and to refine their profile through conversation.

### Context:
User's Current Profile: {{{JSON currentAssessment}}}

### Guidelines:
1. Be fun, encouraging, and highly professional.
2. Use the user's current profile to personalize every answer.
3. If the user mentions a new interest or a skill they've improved (or want to improve), include a "suggestedAssessmentUpdate" in your JSON output. 
4. The "suggestedAssessmentUpdate" should only include the fields that changed.
5. Keep responses concise but helpful.

### Conversation History:
{{#each history}}
{{role}}: {{{text}}}
{{/each}}
user: {{{userInput}}}
`,
});

const aiChatBotFlow = ai.defineFlow(
  {
    name: 'aiChatBotFlow',
    inputSchema: AiChatBotInputSchema,
    outputSchema: AiChatBotOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

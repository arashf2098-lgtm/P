'use server';
/**
 * @fileOverview This file implements a Genkit flow to generate a personalized learning roadmap
 * for a given career or sport recommendation, taking into account the user's profile.
 *
 * - aiLearningRoadmap - A function that handles the generation of the learning roadmap.
 * - AiLearningRoadmapInput - The input type for the aiLearningRoadmap function.
 * - AiLearningRoadmapOutput - The return type for the aiLearningRoadmap function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const UserProfileSchema = z.object({
  age: z.number().optional().describe('User\'s age.'),
  gender: z.string().optional().describe('User\'s gender.'),
  country: z.string().optional().describe('User\'s country of residence.'),
  educationLevel: z
    .enum([
      'Middle School',
      'High School',
      'College',
      'Bachelor',
      'Master',
      'PhD',
    ])
    .describe('User\'s highest education level.'),
  monthlyHobbyBudget: z
    .number()
    .describe('User\'s monthly budget allocated for hobbies and learning.'),
  educationBudget: z
    .number()
    .describe('User\'s budget allocated for education and training.'),
  internetAccess: z.boolean().describe('Whether the user has internet access.'),
  transportationAccess: z
    .boolean()
    .describe('Whether the user has access to transportation.'),
  freeTimePerWeek: z
    .number()
    .describe('Number of free hours per week the user has for activities.'),
  skills: z
    .object({
      mathematics: z.number().min(1).max(10),
      problemSolving: z.number().min(1).max(10),
      communication: z.number().min(1).max(10),
      leadership: z.number().min(1).max(10),
      creativity: z.number().min(1).max(10),
      programming: z.number().min(1).max(10),
      physicalFitness: z.number().min(1).max(10),
      coordination: z.number().min(1).max(10),
      teamwork: z.number().min(1).max(10),
      discipline: z.number().min(1).max(10),
    })
    .describe('User\'s self-assessed skill levels on a scale of 1-10.'),
  interests: z
    .array(z.string())
    .describe(
      'List of user\'s interests, e.g., Technology, Science, Sports, Arts.'
    ),
  additionalPreferences: z
    .object({
      indoorVsOutdoor: z.enum(['Indoor', 'Outdoor', 'Both']),
      teamVsIndividual: z.enum(['Team', 'Individual', 'Both']),
      analyticalVsCreative: z.enum(['Analytical', 'Creative', 'Both']),
      physicalVsMental: z.enum(['Physical', 'Mental', 'Both']),
    })
    .describe('User\'s preferences regarding activity types.'),
  physicalInformation: z
    .object({
      height: z.number().optional().describe('User\'s height in cm.'),
      weight: z.number().optional().describe('User\'s weight in kg.'),
      fitnessLevel: z
        .string()
        .optional()
        .describe('User\'s self-assessed fitness level (e.g., Beginner, Advanced).'),
      existingInjuries: z
        .array(z.string())
        .optional()
        .describe('List of user\'s existing injuries.'),
      sportsExperience: z
        .string()
        .optional()
        .describe('User\'s general sports experience (e.g., None, Some, Experienced).'),
    })
    .optional()
    .describe('Optional physical information about the user.'),
});

const CareerRecommendationSchema = z.object({
  type: z.literal('career').describe('Indicates this is a career recommendation.'),
  name: z.string().describe('Name of the recommended career.'),
  matchPercentage: z.number().describe('Match score for the career (0-100).'),
  averageSalary: z.number().describe('Average annual salary for the career.'),
  difficulty: z.string().describe('Difficulty level of the career (e.g., Low, Medium, High).'),
  learningTime: z.string().describe('Estimated time to learn the career (e.g., 1-2 years).'),
  growthOutlook: z.string().describe('Growth outlook for the career (e.g., High, Medium, Low).'),
  requiredSkills: z.array(z.string()).describe('List of key skills required for the career.'),
  description: z.string().describe('A brief description of the career.'),
});

const SportRecommendationSchema = z.object({
  type: z.literal('sport').describe('Indicates this is a sport recommendation.'),
  name: z.string().describe('Name of the recommended sport.'),
  matchPercentage: z.number().describe('Match score for the sport (0-100).'),
  equipmentCost: z.number().describe('Estimated cost of equipment for the sport.'),
  fitnessBenefits: z.string().describe('Fitness benefits associated with the sport.'),
  difficulty: z.string().describe('Difficulty level of the sport (e.g., Low, Medium, High).'),
  trainingFrequency: z.string().describe('Recommended training frequency for the sport.'),
  description: z.string().describe('A brief description of the sport.'),
});

const RecommendationSchema = z
  .union([
    CareerRecommendationSchema,
    SportRecommendationSchema,
  ])
  .describe('Details of the recommended career or sport.');

export const AiLearningRoadmapInputSchema = z.object({
  userProfile: UserProfileSchema.describe(
    'Comprehensive user profile including skills, interests, budget, education, and physical information.'
  ),
  recommendation: RecommendationSchema.describe(
    'Details of the recommended career or sport for which to generate a learning roadmap.'
  ),
});

export type AiLearningRoadmapInput = z.infer<typeof AiLearningRoadmapInputSchema>;

const LearningRoadmapStepSchema = z.object({
  name: z.string().describe('Short title for the step.'),
  description: z
    .string()
    .describe('Detailed description of what to do in this step.'),
  resources: z
    .array(z.string())
    .describe(
      'List of specific resources for this step.'
    ),
  timeline: z
    .string()
    .describe('Estimated time to complete this step (e.g., "1-2 weeks", "3 months").'),
});

const GlobalResourceSchema = z.object({
  title: z.string().describe('Name of the resource'),
  type: z.enum(['course', 'book', 'community', 'tool', 'website']).describe('Type of resource'),
  description: z.string().describe('Why this is essential'),
  url: z.string().optional().describe('Placeholder or real URL if known'),
});

export const AiLearningRoadmapOutputSchema = z.object({
  title: z.string().describe('A title for the learning roadmap.'),
  introduction: z
    .string()
    .describe('An introductory paragraph for the roadmap, explaining its purpose.'),
  steps: z
    .array(LearningRoadmapStepSchema)
    .describe(
      'An ordered list of steps to follow to get started or progress in the recommended career/sport.'
    ),
  foundationalResources: z.array(GlobalResourceSchema).describe('A master list of resources for this specific career/sport path.'),
  conclusion: z
    .string()
    .describe('A concluding paragraph offering encouragement or next steps.'),
});

export type AiLearningRoadmapOutput = z.infer<typeof AiLearningRoadmapOutputSchema>;

export async function aiLearningRoadmap(
  input: AiLearningRoadmapInput
): Promise<AiLearningRoadmapOutput> {
  return aiLearningRoadmapFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiLearningRoadmapPrompt',
  input: { schema: AiLearningRoadmapInputSchema },
  output: { schema: AiLearningRoadmapOutputSchema },
  prompt: `You are an expert career and sports development coach. Your task is to generate a personalized learning roadmap for a user interested in a specific recommendation, considering their unique profile.

### User Profile:
Education Level: {{{userProfile.educationLevel}}}
Monthly Hobby Budget: $ {{{userProfile.monthlyHobbyBudget}}}
Education Budget: $ {{{userProfile.educationBudget}}}
Free Time Per Week: {{{userProfile.freeTimePerWeek}}} hours
Internet Access: {{#if userProfile.internetAccess}}Yes{{else}}No{{/if}}
Transportation Access: {{#if userProfile.transportationAccess}}Yes{{else}}No{{/if}}

User's Skills (1-10):
{{#each userProfile.skills}}
- {{ @key }}: {{ this }}
{{/each}}

User's Interests: {{#each userProfile.interests}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}

### Recommendation:
Name: {{{recommendation.name}}} ({{{recommendation.type}}})
Description: {{{recommendation.description}}}

### Task:
1. Create a detailed 5-7 step roadmap.
2. Provide a master list of "Foundational Resources". Include real-world platform names (e.g., Coursera, Udemy, local clubs, specific books).
3. Tailor the timeline and resource costs to the user's budget and free time.
`
});

const aiLearningRoadmapFlow = ai.defineFlow(
  {
    name: 'aiLearningRoadmapFlow',
    inputSchema: AiLearningRoadmapInputSchema,
    outputSchema: AiLearningRoadmapOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

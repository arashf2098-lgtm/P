'use server';
/**
 * @fileOverview An AI agent that generates a personalized improvement plan for users.
 *
 * - aiImprovementPlan - A function that handles the generation of an improvement plan.
 * - AiImprovementPlanInput - The input type for the aiImprovementPlan function.
 * - AiImprovementPlanOutput - The return type for the aiImprovementPlan function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiImprovementPlanInputSchema = z.object({
  userSkills: z
    .record(z.number())
    .describe('A map of user skills and their ratings (1-10).'),
  userInterests: z.array(z.string()).describe('A list of user interests.'),
  userEducationLevel: z
    .string()
    .describe('The user\'s highest education level.'),
  careerRecommendations: z
    .array(
      z.object({
        name: z.string().describe('The name of the recommended career.'),
        matchPercentage: z
          .number()
          .describe('The match percentage for the career (0-100).'),
        requiredSkills: z
          .array(z.string())
          .describe('A list of skills required for this career.'),
      })
    )
    .describe('A list of recommended careers with their details.'),
  sportRecommendations: z
    .array(
      z.object({
        name: z.string().describe('The name of the recommended sport.'),
        matchPercentage: z
          .number()
          .describe('The match percentage for the sport (0-100).'),
        fitnessBenefits: z
          .string()
          .describe('A description of the fitness benefits of this sport.'),
      })
    )
    .describe('A list of recommended sports with their details.'),
});
export type AiImprovementPlanInput = z.infer<
  typeof AiImprovementPlanInputSchema
>;

const AiImprovementPlanOutputSchema = z.object({
  summary: z
    .string()
    .describe('A concise summary of the improvement plan.'),
  keySkillsToDevelop: z
    .array(z.string())
    .describe('A list of specific skills the user should develop.'),
  actionableSteps: z
    .array(z.string())
    .describe('Concrete, practical steps the user can take.'),
  resourceSuggestions: z
    .array(z.string())
    .describe('Suggestions for resources (e.g., online courses, books, programs).'),
  motivationalSummary: z
    .string()
    .describe('A brief motivational message encouraging the user.'),
});
export type AiImprovementPlanOutput = z.infer<
  typeof AiImprovementPlanOutputSchema
>;

export async function aiImprovementPlan(
  input: AiImprovementPlanInput
): Promise<AiImprovementPlanOutput> {
  return aiImprovementPlanFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiImprovementPlanPrompt',
  input: {schema: AiImprovementPlanInputSchema},
  output: {schema: AiImprovementPlanOutputSchema},
  prompt: `You are an expert career and sports advisor. Your goal is to create a personalized improvement plan for a user, based on their profile and recommendations. 

User Profile:
- Skills: {{{userSkills}}}
- Interests: {{{userInterests}}}
- Education Level: {{{userEducationLevel}}}

Career Recommendations:
{{#each careerRecommendations}}
- {{{this.name}}} ({{{this.matchPercentage}}}% match)
{{/each}}

Sport Recommendations:
{{#each sportRecommendations}}
- {{{this.name}}} ({{{this.matchPercentage}}}% match)
{{/each}}

Based on the above, generate a comprehensive improvement plan including:
1. A strategic summary.
2. 3-5 key skills to prioritize.
3. 3-5 actionable steps to take immediately.
4. Relevant learning resources.
5. A motivational closing statement.
`,
});

const aiImprovementPlanFlow = ai.defineFlow(
  {
    name: 'aiImprovementPlanFlow',
    inputSchema: AiImprovementPlanInputSchema,
    outputSchema: AiImprovementPlanOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);

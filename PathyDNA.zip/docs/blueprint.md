# **App Name**: PathFinder

## Core Features:

- Secure User Authentication: Enable users to securely sign up, log in, and manage their sessions with email/password and Google OAuth, supporting protected routes.
- Personalized Assessment Flow: A multi-step, auto-saving wizard to gather comprehensive user data including personal information, budget, skills, interests, and physical attributes.
- AI-Powered Recommendation Engine: Calculates matching scores for careers and sports based on user profiles and predefined formulas.
- AI-Generated Insights & Plans Tool: A generative AI tool that provides personalized explanations, career transition advice, improvement plans, learning roadmaps, and motivational summaries based on user recommendations.
- Interactive Recommendation Display: Showcase personalized career and sport matches with detailed cards including match percentages, descriptions, and learning roadmaps, with options to save favorites.
- User Dashboard & History: A central hub for users to view their recommendations, assessment history, manage favorites, and update profile settings.
- Essential Admin Panel: Basic administrative functionalities to create, edit, and delete career and sport entries to manage platform content.

## Style Guidelines:

- Primary color: A deep, rich blue-violet (#6165E6) to convey a sense of professionalism and digital sophistication, designed to stand out against a darker background.
- Background color: A subtle, dark muted blue-grey (#212226), derived from the primary hue but heavily desaturated to provide a clean and sophisticated base, suitable for a dark mode aesthetic.
- Accent color: A vibrant, bright blue-cyan (#85CBFF) for highlighting interactive elements and call-to-actions, providing high contrast and visual interest while remaining harmonious with the primary palette.
- Headline and body font: 'Inter' (sans-serif) for its modern, clean, and objective aesthetic, ensuring high readability and a professional appearance across the dashboard and textual content.
- Utilize minimalist, professional vector icons that align with the clean design, enhancing usability without clutter.
- Employ a modern dashboard-focused layout featuring rounded cards, subtle shadows, and selective glassmorphism accents for depth and a premium feel.
- Incorporate smooth, subtle animations, particularly for transitions between assessment steps and element interactions, to enhance the user experience without distraction.
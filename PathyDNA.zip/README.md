# PathyDNA | AI Skill DNA & Career Growth

PathyDNA is an AI-powered discovery platform that decodes your unique skills, physical predispositions, and interests to map your peak professional and athletic trajectory.

## 🚀 How to Publish (Production Deployment)

PathyDNA is optimized for **Firebase App Hosting**. Follow these steps to go live:

1. **GitHub Sync**: Push this project to a private or public GitHub repository.
2. **Firebase Console**: 
   - Visit [Firebase Console](https://console.firebase.google.com/).
   - Select your project.
   - Navigate to **App Hosting** in the sidebar.
3. **Setup Pipeline**:
   - Click **Get Started**.
   - Connect your GitHub account and select the repository.
   - Select your branch (e.g., `main`).
4. **Environment Variables**:
   - In the App Hosting dashboard, go to the **Settings** tab.
   - Add the following keys from your `src/firebase/config.ts` as Environment Variables:
     - `NEXT_PUBLIC_FIREBASE_API_KEY`
     - `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
     - `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
     - `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
     - `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
     - `NEXT_PUBLIC_FIREBASE_APP_ID`
5. **Domain**: Firebase will provide a `.web.app` or `.apphosting.com` URL. You can also connect a custom domain like `pathydna.com` in the Hosting settings.

## 🛠 Features

- **AI Skill DNA**: Multi-dimensional profiling.
- **Tactical Scheduler**: Persistence-based daily habit tracking.
- **Future Vision**: AI-generated vision boards using Imagen 4.
- **Pathy Chatbot**: Conversational profile refining.

## 📈 Search Optimization (SEO)

To find your site on Google:
- Search for the unique name: **"PathyDNA"**.
- Ensure you have submitted your `sitemap.xml` to [Google Search Console](https://search.google.com/search-console).
